# Temporal Dynamics of EEG Power During Mindfulness Meditation

This repository contains the Python analysis code used for the study:

**Temporal stability of the absolute EEG spectrum and non-monotonic relative-power redistribution during sustained mindfulness meditation in expert Buddhist monks**

The project re-analyses the openly available Wongupparaj (2024) EEG band-power dataset from 60 experienced Thai Buddhist monks during a 30-minute mindfulness meditation session, segmented into six 5-minute intervals.

## Main analysis questions

1. Does EEG spectral power change systematically during a 30-minute meditation session?
2. Are temporal changes monotonic or curvilinear?
3. Do temporal trajectories differ across ordination-defined experience cohorts after age adjustment?
4. Can a time-averaged spatial-spectral pattern distinguish seniority cohorts independently of age?

## Repository structure

```text
meditation-eeg-github/
├── notebooks/
│   ├── meditation_eeg_analysis_v3.ipynb      # Main executable notebook
│   └── validation_standalone.ipynb           # Independent validation checks
├── src/meditation_eeg/
│   ├── analysis_raw.py                       # Script export of the main notebook
│   └── validation_raw.py                     # Script export of validation notebook
├── docs/
│   ├── DATASET_AND_METHODS.md
│   └── GITHUB_PUBLISHING_CHECKLIST.md
├── outputs/
│   ├── figures/                             # Generated figures, ignored by Git
│   └── tables/                              # Generated CSV tables, ignored by Git
├── requirements.txt
├── .gitignore
├── LICENSE
└── CITATION.cff
```

## Data

The dataset is not included in this repository. Download it from Mendeley Data:

**Wongupparaj P. (2024). EEG absolute and relative powers during mindfulness meditation: data from Thai Buddhist monks. Mendeley Data, V1. DOI: 10.17632/pthdhf2dwm.1**

Place the extracted dataset under:

```text
data/raw/
```

or set the dataset path using an environment variable:

```bash
export EEG_DATA_ROOT="/path/to/extracted/dataset"
```

## Installation

```bash
git clone https://github.com/<your-username>/meditation-eeg-temporal-dynamics.git
cd meditation-eeg-temporal-dynamics
python -m venv .venv
source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

## Running the notebooks

```bash
jupyter lab
```

Open and run:

```text
notebooks/meditation_eeg_analysis_v3.ipynb
```

Then run the standalone validation notebook:

```text
notebooks/validation_standalone.ipynb
```

## Running as scripts

```bash
export EEG_DATA_ROOT="/path/to/extracted/dataset"
export EEG_OUTPUT_DIR="./outputs"
python src/meditation_eeg/analysis_raw.py
python src/meditation_eeg/validation_raw.py
```

## Expected outputs

The pipeline generates:

- cleaned long-format EEG table
- ROI-level absolute and relative power tables
- mixed-effects trajectory model results
- FDR-corrected linear and quadratic trend tables
- alpha trajectory phenotype figure
- experience-group decoding feature-importance table
- publication-quality figures in PNG and PDF formats

## Method summary

The analysis uses:

- scalp-channel filtering and non-EEG channel removal
- five EEG frequency bands: delta, theta, alpha, beta, gamma
- five anatomical regions of interest: frontal, central, temporal, parietal, occipital
- log10 transformation of power values
- linear mixed-effects models with subject-level random intercepts and slopes
- likelihood-ratio testing of linear and quadratic time effects
- Benjamini-Hochberg false-discovery-rate correction
- age-adjusted time-by-cohort interaction testing
- centered-log-ratio validation for relative-power compositionality
- random-forest decoding of ordination cohort

## Reproducibility note

The notebooks are the recommended execution path because they show intermediate audit tables and diagnostics. The exported scripts are provided for command-line reproducibility and GitHub archiving.

## Citation

Please cite the original dataset and the related manuscript when using this code.
