# Dataset and Methods

## Dataset

The analysis uses the public Wongupparaj (2024) Mendeley Data EEG dataset. The dataset contains absolute and relative EEG band-power features from 60 Thai Buddhist monks recorded during a single 30-minute mindfulness meditation session.

The 30-minute recording is divided into six 5-minute intervals:

1. 0–5 min
2. 5–10 min
3. 10–15 min
4. 15–20 min
5. 20–25 min
6. 25–30 min

The analysed bands are:

- Delta: 0.5–4 Hz
- Theta: 4–8 Hz
- Alpha: 8–12 Hz
- Beta: 12–30 Hz
- Gamma: 30–45 Hz

## Pre-processing implemented in the code

The repository starts from the deposited band-power Excel files, not from raw EEG time-series recordings. The code:

1. recursively discovers subject-level Excel workbooks;
2. extracts subject ID, group, frequency band, time interval and electrode values;
3. removes non-scalp channels such as mastoid, trigger, event and EOG/ECG-style channels;
4. detects whether workbooks contain absolute or relative power using the constant-sum property of relative power;
5. reconstructs relative power from absolute power when a complete deposited relative-power set is unavailable;
6. aggregates electrodes into anatomical regions of interest.

## Regions of interest

The code maps scalp electrodes into five ROIs:

- Frontal
- Central
- Temporal
- Parietal
- Occipital

ROI-level power is computed as the mean across electrodes within each region for every participant, band, interval and power type.

## Statistical analysis

For each band and ROI, the pipeline fits mixed-effects models with participant-level random effects. It tests:

- linear time trend;
- quadratic time curvature;
- whether quadratic models improve fit over linear models;
- age-adjusted time-by-group interaction.

P-values are corrected across the 25 band-by-region tests using Benjamini-Hochberg false-discovery-rate correction.

## Validation checks

The standalone validation notebook performs three important checks:

1. group-mean relative power across intervals;
2. leave-one-interval-out robustness of the strongest curvature effect;
3. centered-log-ratio validation of relative-power curvature to address compositional constraints.

## Important limitation

The analysis uses pre-computed band-power features. It cannot perform source localization, connectivity, microstate analysis, or periodic/aperiodic spectral decomposition unless raw EEG time-series data are obtained.
