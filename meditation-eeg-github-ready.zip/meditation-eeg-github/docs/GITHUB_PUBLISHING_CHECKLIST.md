# GitHub Publishing Checklist

Before making the repository public, complete the following steps.

## 1. Remove private information

- Remove local Windows paths from notebooks if visible in outputs.
- Clear notebook outputs if they contain private folder names.
- Confirm that no participant-identifying information beyond the public dataset identifiers is included.
- Do not upload the downloaded dataset unless its license explicitly permits redistribution.

## 2. Update repository placeholders

Replace:

```text
<your-username>
```

in:

- README.md
- CITATION.cff

## 3. Add manuscript information

When available, update:

- final paper title
- author names
- DOI or preprint URL
- journal name
- repository URL

## 4. Test the clean run

From a fresh environment:

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
export EEG_DATA_ROOT="/path/to/dataset"
export EEG_OUTPUT_DIR="./outputs"
python src/meditation_eeg/analysis_raw.py
python src/meditation_eeg/validation_raw.py
```

## 5. Recommended first commit

```bash
git init
git add README.md requirements.txt LICENSE CITATION.cff .gitignore docs notebooks src
git commit -m "Initial release of meditation EEG temporal dynamics analysis"
git branch -M main
git remote add origin https://github.com/<your-username>/meditation-eeg-temporal-dynamics.git
git push -u origin main
```
