"""Meditation EEG temporal-dynamics analysis package.

This repository accompanies the EEG mindfulness meditation re-analysis.
"""

__version__ = "0.1.0"
