#!/usr/bin/env python
# coding: utf-8

# # Temporal dynamics of EEG power during mindfulness meditation — v3 (corrected)
# 
# Dataset: Wongupparaj (2024), Mendeley DOI 10.17632/pthdhf2dwm.1.
# 
# **What changed in v3 (driven by the real-data run):**
# 1. **Robust absolute/relative detection** by the *constant-sum* property (relative power sums to a
#    near-constant ~100 across electrodes; CV<5%). v2's magnitude-only rule misread ~20 absolute
#    files as relative and broke the relative-dependent cells.
# 2. **Relative power is computed from absolute** (100*band/Sum_bands) when a complete provided
#    relative set is absent — guaranteeing all 60 subjects. A genuinely deposited, complete relative
#    set is used instead if found. A folder probe prints the directory tree so you can spot a
#    provided relative folder.
# 3. **Age is now a covariate.** The cohorts (Group1/2/3) differ steeply in age (~30/39/52 yrs) as
#    well as ordination, so the time x group interaction is **age-adjusted**, and Section 4 reports
#    how well the same features predict age — if age is highly predictable, "experience" decoding is
#    partly an age effect.
# 
# Run Section 0 first and read the audit.

# ## CONFIG

# In[1]:


from pathlib import Path

# Point this at the folder that contains BOTH the absolute and relative power folders.
# (In v1 you pointed it at the absolute tree only; go one level up so relative is included.)
DATA_ROOT = Path(__import__("os").environ.get("EEG_DATA_ROOT", "./data/raw"))

# Optional: if relative power lives in a completely separate folder, set it here; else leave None.
RELATIVE_ROOT = None

PARTICIPANT_FILE = None        # None -> auto-search
OUTPUT_DIR = Path(__import__("os").environ.get("EEG_OUTPUT_DIR", "./outputs"))
EXPERIENCE_COL = None          # None -> auto (Meditation_length / level / ...)

LOG_TRANSFORM = True           # analyse log10(power); strongly recommended
RANDOM_STATE = 42
FIG_DPI = 600

# Channels that are not scalp EEG and must be dropped before any analysis.
NON_EEG = {"M1", "M2", "A1", "A2", "CONDITION", "TRIGGER", "STATUS", "EVENT", "TIME",
           "HEO", "VEO", "HEOG", "VEOG", "EOG", "ECG", "EKG", "EMG", "REF", "GND"}
# Add "CB1","CB2" here if you prefer to drop the inion/cerebellar channels too.

OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
(OUTPUT_DIR / "figures").mkdir(exist_ok=True)
(OUTPUT_DIR / "tables").mkdir(exist_ok=True)


# ## Imports & style

# In[2]:


import re, warnings
try:
    from IPython.display import display
except Exception:
    def display(x):
        print(x)
import numpy as np, pandas as pd
import matplotlib.pyplot as plt, seaborn as sns
from scipy import stats
import statsmodels.formula.api as smf
from statsmodels.stats.multitest import multipletests
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import RidgeCV
from sklearn.ensemble import RandomForestRegressor, RandomForestClassifier
from sklearn.model_selection import KFold, StratifiedKFold, cross_val_score, permutation_test_score
from sklearn.pipeline import make_pipeline

np.random.seed(RANDOM_STATE)
warnings.filterwarnings("ignore")
OKABE_ITO = ["#0072B2", "#D55E00", "#009E73", "#CC79A7", "#E69F00", "#56B4E9", "#F0E442", "#000000"]
sns.set_theme(context="paper", style="whitegrid", font_scale=1.1)
plt.rcParams.update({"figure.dpi": 120, "savefig.dpi": FIG_DPI, "savefig.bbox": "tight",
                     "axes.prop_cycle": plt.cycler(color=OKABE_ITO), "font.family": "DejaVu Sans",
                     "pdf.fonttype": 42, "ps.fonttype": 42})
BAND_ORDER = ["Delta", "Theta", "Alpha", "Beta", "Gamma"]
INTERVAL_ORDER = ["0-5min", "5-10min", "10-15min", "15-20min", "20-25min", "25-30min"]
TIME_MID = {iv: 2.5 + 5 * i for i, iv in enumerate(INTERVAL_ORDER)}


def savefig(fig, name):
    p = OUTPUT_DIR / "figures" / name
    fig.savefig(p); fig.savefig(p.with_suffix(".pdf"))
    print(f"  saved figure -> {p}")


# ## SECTION 0 — Load & AUDIT (power type detected by magnitude)

# In[3]:


def _read_excel_any(path):
    p = str(Path(path).resolve())
    if len(p) > 250 and p[1:3] == ":\\":
        p = "\\\\?\\" + p
    for eng in ("calamine", "openpyxl"):
        try:
            return pd.read_excel(p, engine=eng)
        except Exception:
            continue
    return pd.read_excel(p)


def _parse_interval(text):
    m = re.search(r"(\d+)\s*[-_]\s*(\d+)\s*min", str(text).lower())
    return f"{int(m.group(1))}-{int(m.group(2))}min" if m else None


def _parse_subject(path: Path):
    for token in [path.stem] + [p.name for p in path.parents]:
        m = re.search(r"\bE\d+-\d+\b", token)
        if m:
            return m.group(0)
    return path.parent.name


META_HINTS = {"file", "freq_int_name", "freq_interval", "freq", "band", "interval",
              "subject", "subject_id", "group", "time", "time_interval", "unnamed: 0"}


def _detect_band_and_electrodes(df):
    band_col = None
    for c in df.columns:
        if str(c).strip().lower() in {"freq_int_name", "band", "freq", "frequency"}:
            band_col = c; break
    if band_col is None:
        for c in df.columns:
            if df[c].astype(str).str.lower().isin([b.lower() for b in BAND_ORDER]).mean() > 0.5:
                band_col = c; break
    electrodes = [c for c in df.columns
                  if str(c).strip().lower() not in META_HINTS and c != band_col
                  and str(c).strip().upper() not in NON_EEG
                  and pd.api.types.is_numeric_dtype(df[c])]
    return band_col, electrodes


def classify_power_type(file_df, band_col, electrodes):
    """Genuine relative power sums to a NEAR-CONSTANT (~100% or ~1) across the 5 bands for every
    electrode -> coefficient of variation of the per-electrode band-sums is ~0. Absolute power
    sums to wildly different totals across electrodes (high CV). Using the CV avoids the v2 failure
    where some absolute files summed near 100 and were misread as relative."""
    sub = file_df[file_df[band_col].astype(str).str.title().isin(BAND_ORDER)]
    if sub.empty or not electrodes:
        return "unknown"
    band_sum = sub[electrodes].sum(axis=0).values.astype(float)
    band_sum = band_sum[np.isfinite(band_sum)]
    if band_sum.size == 0:
        return "unknown"
    med = float(np.median(band_sum))
    cv = float(np.std(band_sum) / (abs(med) + 1e-12))
    if cv < 0.05 and (90 <= med <= 110 or 0.9 <= med <= 1.1):
        return "relative"
    return "absolute"


def load_dataset(roots):
    rows, prov = [], []
    files = []
    for root in roots:
        files += [p for p in Path(root).rglob("*.xlsx")
                  if "participant" not in p.name.lower() and not p.name.startswith("~$")]
    print(f"Discovered {len(files)} candidate EEG workbooks.\n")
    for f in files:
        interval = _parse_interval(f.name) or _parse_interval(f.parent.name)
        if interval is None:
            continue
        subj = _parse_subject(f)
        grp = next((p.name for p in f.parents if re.match(r"group", p.name, re.I)), "NA")
        try:
            df = _read_excel_any(f)
        except Exception as e:
            print(f"  ! read fail {f.name}: {e}"); continue
        band_col, electrodes = _detect_band_and_electrodes(df)
        if band_col is None or not electrodes:
            continue
        ptype = classify_power_type(df, band_col, electrodes)
        long = df.melt(id_vars=[band_col], value_vars=electrodes,
                       var_name="electrode", value_name="power").rename(columns={band_col: "band"})
        long["band"] = long["band"].astype(str).str.strip().str.title()
        long = long[long["band"].isin(BAND_ORDER)]
        long["subject_id"], long["group"] = subj, grp
        long["time_interval"], long["power_type"] = interval, ptype
        rows.append(long)
    tidy = pd.concat(rows, ignore_index=True)
    tidy["power"] = pd.to_numeric(tidy["power"], errors="coerce")
    return tidy.dropna(subset=["power"])


roots = [DATA_ROOT] + ([RELATIVE_ROOT] if RELATIVE_ROOT else [])
tidy = load_dataset(roots)

print("=" * 78 + "\nAUDIT\n" + "=" * 78)
print("Tidy shape:", tidy.shape)
print("Power types (by magnitude):", dict(tidy["power_type"].value_counts()))
print("  per-type subject counts:", {pt: g["subject_id"].nunique()
                                      for pt, g in tidy.groupby("power_type")})
print("Bands:", sorted(tidy["band"].unique()))
print("Intervals:", sorted(tidy["time_interval"].unique(), key=lambda s: int(s.split('-')[0])))
print("N subjects:", tidy["subject_id"].nunique(), "| N electrodes (after NON_EEG drop):",
      tidy["electrode"].nunique())
print("Groups:", dict(tidy.groupby("group")["subject_id"].nunique()))
print("Electrodes:", ", ".join(sorted(tidy["electrode"].unique())))

# ---- Locate any provided relative-power folder (diagnostic) --------------------------------
print("\nFolder tree (2 levels up from DATA_ROOT) — look for a separate relative-power folder:")
try:
    base = DATA_ROOT.parent
    for d in sorted([p for p in base.iterdir() if p.is_dir()]):
        print("  ", d.name)
        for sub in sorted([p for p in d.iterdir() if p.is_dir()])[:6]:
            print("      ", sub.name)
except Exception as e:
    print("   (could not list:", e, ")")

# ---- Build a COMPLETE, correct relative-power set -------------------------------------------
# Relative power := 100 * band_power / sum_over_bands(band_power), per subject x interval x
# electrode. We keep a provided 'relative' set ONLY if it is complete (same #subjects as absolute,
# i.e. genuinely deposited), otherwise we drop the spurious partial set and compute relative from
# absolute (the standard definition, which equals the authors' relative up to rounding).
n_abs = tidy.loc[tidy["power_type"] == "absolute", "subject_id"].nunique()
n_rel = tidy.loc[tidy["power_type"] == "relative", "subject_id"].nunique()
abs_tbl = tidy[tidy["power_type"] == "absolute"].copy()
if n_rel >= n_abs and n_rel > 0:
    print(f"\nUsing PROVIDED relative power ({n_rel} subjects).")
else:
    if n_rel > 0:
        print(f"\n[fix] Dropping spurious partial 'relative' set ({n_rel} subjects) and computing "
              f"relative from absolute for all {n_abs} subjects.")
        tidy = tidy[tidy["power_type"] != "relative"].copy()
    else:
        print(f"\n[info] No provided relative power; computing it from absolute for {n_abs} subjects.")
    tot = (abs_tbl.groupby(["subject_id", "time_interval", "electrode"])["power"]
                  .transform("sum"))
    rel = abs_tbl.copy()
    rel["power"] = 100.0 * rel["power"] / tot.replace(0, np.nan)
    rel["power_type"] = "relative"
    tidy = pd.concat([tidy[tidy["power_type"] != "relative"], rel.dropna(subset=["power"])],
                     ignore_index=True)

print("Power types now:", {pt: g["subject_id"].nunique() for pt, g in tidy.groupby("power_type")})
tidy.to_csv(OUTPUT_DIR / "tables" / "tidy_long.csv", index=False)


# ## Participants + confirm what `Group` encodes (hardened against constant columns)

# In[4]:


def find_participant_file(data_root, override):
    if override:
        return Path(override)
    for d in [data_root, data_root.parent, data_root.parent.parent]:
        for p in Path(d).rglob("*articipant*.xlsx"):
            if not p.name.startswith("~$"):
                return p
    return None


pfile = find_participant_file(DATA_ROOT, PARTICIPANT_FILE)
participants, SUBJ_COL = None, None
if pfile and pfile.exists():
    participants = _read_excel_any(pfile)
    participants.columns = [str(c).strip() for c in participants.columns]
    print("Participant file:", pfile.name, "| columns:", list(participants.columns))
    for c in participants.columns:
        if participants[c].astype(str).str.match(r"E\d+-\d+").mean() > 0.5:
            SUBJ_COL = c; break
    SUBJ_COL = SUBJ_COL or participants.columns[0]
    print("Subject-id column:", SUBJ_COL)
    display(participants.head())
else:
    print("[!] Participant file not found; behavioural sections will be skipped.")

if participants is not None and tidy["group"].nunique() > 1:
    print("\n" + "-" * 78 + "\nWHAT IS 'Group'?  (Kruskal across groups; constant columns skipped)\n" + "-" * 78)
    grp_map = tidy.groupby("subject_id")["group"].first()
    pdf = participants.copy(); pdf["__group__"] = pdf[SUBJ_COL].map(grp_map)
    for c in [c for c in pdf.columns if c not in (SUBJ_COL, "__group__")
              and pd.api.types.is_numeric_dtype(pdf[c])]:
        vals = [g[c].dropna().values for _, g in pdf.groupby("__group__")]
        vals = [v for v in vals if len(v) > 1]
        if len(vals) < 2 or len({tuple(np.round(np.unique(v), 6)) for v in vals}) == 1 \
                or np.unique(np.concatenate(vals)).size < 2:
            print(f"  {c:<22} (constant / insufficient variation — skipped)"); continue
        try:
            H, p = stats.kruskal(*vals)
            print(f"  {c:<22} H={H:6.2f}  p={p:.4f}{'   <-- differs by group' if p < 0.05 else ''}")
        except ValueError:
            print(f"  {c:<22} (constant — skipped)")
    print("\nGroup means of key variables:")
    keyvars = [c for c in ["Age", "Ordination", "Meditation_length", "Meditation_level",
                           "Meditation_practice"] if c in pdf.columns]
    display(pdf.groupby("__group__")[keyvars].mean().round(2))
    print("=> If Group tracks Ordination/experience, use it as the experience axis "
          "(time x group below).")


# ## SECTION 1 — ROIs (non-EEG already dropped), log-transform, analysis frame

# In[5]:


def electrode_to_roi(name):
    s = str(name).upper().strip()
    if s.startswith("PO"):                                  return "Parietal"
    if s.startswith(("FP", "AF")):                          return "Frontal"
    if s.startswith("FT"):                                  return "Temporal"
    if s.startswith(("FC", "CP")):                          return "Central"
    if s.startswith("TP"):                                  return "Temporal"
    if s.startswith(("CB", "IZ")):                          return "Occipital"
    if s.startswith("T") and any(ch.isdigit() for ch in s): return "Temporal"
    if s.startswith("O"):                                   return "Occipital"
    if s.startswith("P"):                                   return "Parietal"
    if s.startswith("C"):                                   return "Central"
    if s.startswith("F"):                                   return "Frontal"
    return "Other"


tidy = tidy[~tidy["electrode"].astype(str).str.upper().isin(NON_EEG)].copy()
tidy["roi"] = tidy["electrode"].map(electrode_to_roi)
print("ROI counts (unique electrodes):")
print(tidy.drop_duplicates("electrode").groupby("roi")["electrode"].count())
other = sorted(tidy.loc[tidy["roi"] == "Other", "electrode"].unique())
if other:
    print("[!] Still unmapped (check these):", other)
tidy = tidy[tidy["roi"] != "Other"]

tidy["time_min"] = tidy["time_interval"].map(TIME_MID)
tidy = tidy.dropna(subset=["time_min"])
tidy["y"] = np.log10(tidy["power"].clip(lower=1e-9)) if LOG_TRANSFORM else tidy["power"]
print(f"\nAnalysis variable: {'log10(power)' if LOG_TRANSFORM else 'raw power'}")

roi_tbl = (tidy.groupby(["power_type", "subject_id", "group", "band", "roi",
                         "time_interval", "time_min"], as_index=False)
              .agg(power=("power", "mean"), y=("y", "mean")))
if participants is not None and "Age" in participants.columns:
    age_map = participants.set_index(SUBJ_COL)["Age"]
    roi_tbl["age"] = roi_tbl["subject_id"].map(age_map)
    print("Merged Age (covariate) — group/experience effects will be age-adjusted.")
roi_tbl.to_csv(OUTPUT_DIR / "tables" / "roi_power.csv", index=False)


# ## SECTION 1b — Global drift vs band-specific change (the key interpretive check)
# 
# If absolute power rises in *every* band by a similar factor, that is global amplitude drift, and
# the meaningful signal lives in **relative** power (spectral redistribution). This cell quantifies
# how parallel the band trajectories are.

# In[6]:


for pt in roi_tbl["power_type"].unique():
    sub = roi_tbl[roi_tbl["power_type"] == pt]
    slopes = {}
    for band, d in sub.groupby("band"):
        gm = d.groupby("time_min")["y"].mean()
        slopes[band] = np.polyfit(gm.index, gm.values, 1)[0]
    s = pd.Series(slopes).reindex(BAND_ORDER)
    sign_agreement = (np.sign(s.dropna()) == np.sign(s.dropna()).mode()[0]).mean()
    print(f"[{pt}] mean log-power slope per band (per min): "
          + ", ".join(f"{b}={v:+.4f}" for b, v in s.items()))
    print(f"        -> {sign_agreement*100:.0f}% of bands share the same sign "
          f"({'looks like GLOBAL drift' if sign_agreement==1 and pt=='absolute' else 'mixed/band-specific'})\n")


# ## SECTION 2 (PRIMARY) — Trajectory shape, and does it differ by experience (time x group)?
# 
# Model A: `y ~ t (+ t^2)` with random intercept+slope per subject — overall trajectory shape.
# Model B: `y ~ t * C(group)` vs `y ~ t + C(group)` — likelihood-ratio test for whether the
# trajectory's slope differs across experience cohorts. FDR across band x ROI within each test.

# In[7]:


def trajectory_models(df, power_type):
    sub = df[df["power_type"] == power_type].copy()
    if sub.empty:
        return None
    sub["t"] = (sub["time_min"] - sub["time_min"].mean()) / sub["time_min"].std()
    sub["t2"] = sub["t"] ** 2
    has_group = sub["group"].nunique() > 1
    out = []
    for (band, roi), d in sub.groupby(["band", "roi"]):
        d = d.dropna(subset=["y", "t"])
        if d["subject_id"].nunique() < 5:
            continue
        rec = dict(band=band, roi=roi, n_sub=d["subject_id"].nunique())
        try:
            ml = smf.mixedlm("y ~ t", d, groups=d["subject_id"], re_formula="~t").fit(reml=False)
            mq = smf.mixedlm("y ~ t + t2", d, groups=d["subject_id"], re_formula="~t").fit(reml=False)
            rec.update(lin_slope=ml.fe_params.get("t", np.nan),
                       lin_p=ml.pvalues.get("t", np.nan),
                       quad_p=stats.chi2.sf(max(2*(mq.llf-ml.llf), 0), df=1),
                       better=("quadratic" if mq.aic < ml.aic - 2 else "linear"))
            if has_group:
                cov = " + age" if ("age" in d.columns and d["age"].notna().all()
                                    and d["age"].nunique() > 1) else ""
                m_main = smf.mixedlm(f"y ~ t + C(group){cov}", d, groups=d["subject_id"],
                                     re_formula="~t").fit(reml=False)
                m_int = smf.mixedlm(f"y ~ t * C(group){cov}", d, groups=d["subject_id"],
                                    re_formula="~t").fit(reml=False)
                k = d["group"].nunique() - 1
                rec["timeXgroup_p"] = stats.chi2.sf(max(2*(m_int.llf-m_main.llf), 0), df=k)
                rec["age_adjusted"] = bool(cov)
        except Exception as e:
            rec["error"] = str(e)
        out.append(rec)
    res = pd.DataFrame(out)
    for col in ["lin_p", "quad_p", "timeXgroup_p"]:
        if col in res and res[col].notna().any():
            ok = res[col].notna()
            res.loc[ok, col + "_fdr"] = multipletests(res.loc[ok, col], method="fdr_bh")[1]
    return res


traj = {}
for pt in roi_tbl["power_type"].unique():
    print(f"\n### Trajectory models — {pt}")
    r = trajectory_models(roi_tbl, pt)
    if r is not None and not r.empty:
        traj[pt] = r
        show = [c for c in ["band", "roi", "lin_slope", "lin_p_fdr", "quad_p_fdr",
                            "better", "timeXgroup_p_fdr"] if c in r.columns]
        display(r[show].sort_values(["band", "roi"]).round(4))
        r.to_csv(OUTPUT_DIR / "tables" / f"trajectory_{pt}.csv", index=False)
        if "lin_p_fdr" in r:
            sig = r[r["lin_p_fdr"] < 0.05]
            print(f"  significant linear trends (FDR<.05): {len(sig)} of {len(r)}")


# ### Figure: whole-scalp band trajectories by experience group

# In[8]:


def plot_traj_by_group(df, power_type):
    sub = df[df["power_type"] == power_type]
    g = sub.groupby(["band", "group", "subject_id", "time_min"], as_index=False)["y"].mean()
    fig, axes = plt.subplots(1, len(BAND_ORDER), figsize=(17, 3.3), sharex=True)
    groups = sorted(sub["group"].unique())
    for ax, band in zip(axes, BAND_ORDER):
        b = g[g["band"] == band]
        for j, grp in enumerate(groups):
            st = b[b["group"] == grp].groupby("time_min")["y"].agg(["mean", "sem"])
            ax.plot(st.index, st["mean"], "-o", color=OKABE_ITO[j % 8], lw=1.8, label=grp)
            ax.fill_between(st.index, st["mean"]-1.96*st["sem"], st["mean"]+1.96*st["sem"],
                            alpha=0.18, color=OKABE_ITO[j % 8])
        ax.set_title(band); ax.set_xlabel("Time (min)")
    axes[0].set_ylabel(("log10 " if LOG_TRANSFORM else "") + f"{power_type} power")
    axes[-1].legend(frameon=False, fontsize=8)
    fig.suptitle(f"Band-power trajectories by experience group ({power_type})", y=1.05)
    fig.tight_layout(); savefig(fig, f"trajectory_by_group_{power_type}.png"); plt.show()


for pt in roi_tbl["power_type"].unique():
    plot_traj_by_group(roi_tbl, pt)


# ## SECTION 3 — Trajectory phenotypes; tested against BOTH group and experience

# In[9]:


PHENOTYPE_BAND = "Alpha"
PHENO_PT = "relative" if "relative" in roi_tbl["power_type"].unique() else roi_tbl["power_type"].unique()[0]


def trajectory_matrix(df, band, power_type):
    sub = df[(df["band"] == band) & (df["power_type"] == power_type)]
    wide = (sub.groupby(["subject_id", "time_min"])["y"].mean()
               .unstack("time_min").reindex(columns=sorted(TIME_MID.values()))).dropna()
    Z = wide.sub(wide.mean(1), axis=0).div(wide.std(1).replace(0, np.nan), axis=0).dropna()
    return Z


Z = trajectory_matrix(roi_tbl, PHENOTYPE_BAND, PHENO_PT)
print(f"{PHENOTYPE_BAND} ({PHENO_PT}) shape-matrix: {Z.shape[0]} subjects")
best_k, best_s = 2, -1
for k in range(2, 6):
    if Z.shape[0] <= k:
        break
    s = silhouette_score(Z.values, KMeans(k, n_init=10, random_state=RANDOM_STATE).fit_predict(Z.values))
    print(f"  k={k}: silhouette={s:.3f}")
    if s > best_s:
        best_k, best_s = k, s
pheno = pd.Series(KMeans(best_k, n_init=10, random_state=RANDOM_STATE).fit_predict(Z.values),
                  index=Z.index, name="phenotype")
print(f"Selected k={best_k}; sizes={dict(pheno.value_counts())}")

fig, ax = plt.subplots(figsize=(7, 4.3))
tv = sorted(TIME_MID.values())
for c in sorted(pheno.unique()):
    m = Z.loc[pheno[pheno == c].index]
    ax.plot(tv, m.mean(0), "-o", lw=2.2, color=OKABE_ITO[c % 8], label=f"Phenotype {c+1} (n={len(m)})")
    ax.fill_between(tv, m.mean(0)-m.sem(0), m.mean(0)+m.sem(0), alpha=0.2, color=OKABE_ITO[c % 8])
ax.set_xlabel("Time (min)"); ax.set_ylabel(f"{PHENOTYPE_BAND} (within-subject z)")
ax.set_title(f"{PHENOTYPE_BAND} trajectory phenotypes ({PHENO_PT})"); ax.legend(frameon=False)
savefig(fig, f"phenotypes_{PHENOTYPE_BAND}_{PHENO_PT}.png"); plt.show()

if participants is not None:
    grp_map = tidy.groupby("subject_id")["group"].first()
    ct = pd.crosstab(pheno, pheno.index.map(grp_map))
    print("\nPhenotype x Group:"); display(ct)
    if ct.shape[0] > 1 and ct.shape[1] > 1:
        chi2, p, *_ = stats.chi2_contingency(ct)
        print(f"  chi-square p={p:.3f}")
    EXP = EXPERIENCE_COL or next((c for c in ["Meditation_length", "Meditation_level",
          "Meditation_duration", "Meditation_practice"] if c in participants.columns), None)
    if EXP:
        pmap = participants.set_index(SUBJ_COL)[EXP]
        dfp = pd.DataFrame({"ph": pheno, "exp": pheno.index.map(pmap)}).dropna()
        vals = [g["exp"].values for _, g in dfp.groupby("ph")]
        if len(vals) >= 2 and all(len(v) > 1 for v in vals) and np.unique(np.concatenate(vals)).size > 1:
            H, p = stats.kruskal(*vals)
            print(f"\n{EXP} across phenotypes: Kruskal p={p:.3f}")
            display(dfp.groupby("ph")["exp"].agg(["mean", "std", "count"]).round(2))


# ## SECTION 4 — Expertise: classify experience GROUP from the spatiospectral pattern
# 
# Group is the cleanest experience axis here. We decode it from per-subject relative-power features
# (band x ROI means + temporal slopes), with stratified CV and a permutation null. We also regress
# the ordinal experience score. With n~60 this is exploratory: report effect sizes + permutation p.

# In[ ]:


def subject_features(df, power_type):
    sub = df[df["power_type"] == power_type].copy()
    mean_f = sub.groupby(["subject_id", "band", "roi"])["y"].mean().unstack(["band", "roi"])
    mean_f.columns = [f"{b}_{r}_mean" for b, r in mean_f.columns]

    def _slope(g):
        return np.polyfit(g["time_min"], g["y"], 1)[0] if g["time_min"].nunique() >= 3 else np.nan
    sl = sub.groupby(["subject_id", "band", "roi"]).apply(_slope).unstack(["band", "roi"])
    sl.columns = [f"{b}_{r}_slope" for b, r in sl.columns]
    return mean_f.join(sl)


FEAT_PT = "relative" if "relative" in roi_tbl["power_type"].unique() else roi_tbl["power_type"].unique()[0]
print("Feature power type:", FEAT_PT)
if participants is not None:
    Xf = subject_features(roi_tbl, FEAT_PT)
    grp_map = tidy.groupby("subject_id")["group"].first()

    # --- classification of experience group ---
    if grp_map.nunique() > 1:
        d = Xf.join(grp_map.rename("g")).dropna()
        Xc, yc = d.drop(columns="g").values, d["g"].values
        clf = RandomForestClassifier(n_estimators=400, random_state=RANDOM_STATE)
        cv = StratifiedKFold(5, shuffle=True, random_state=RANDOM_STATE)
        acc, perm, p = permutation_test_score(clf, Xc, yc, cv=cv, scoring="balanced_accuracy",
                                               n_permutations=200, random_state=RANDOM_STATE)
        chance = 1.0 / len(np.unique(yc))
        print(f"\nGroup decoding: balanced acc = {acc:.3f} (chance={chance:.3f}) | perm p = {p:.3f}")
        rf = RandomForestClassifier(n_estimators=600, random_state=RANDOM_STATE).fit(Xc, yc)
        imp = pd.Series(rf.feature_importances_, index=d.drop(columns="g").columns).sort_values(ascending=False)
        print("Top predictors of experience group:"); print(imp.head(10).round(4))
        imp.to_csv(OUTPUT_DIR / "tables" / "group_decoding_importance.csv")
        # Caveat: groups differ in age. If the SAME features predict age well, the "experience"
        # signal is partly age. Report the age baseline alongside the group result.
        if "Age" in participants.columns:
            ya = participants.set_index(SUBJ_COL)["Age"].reindex(d.index)
            ok = ya.notna().values
            if ok.sum() > 10:
                r2age = cross_val_score(RandomForestRegressor(200, random_state=RANDOM_STATE),
                                        Xc[ok], ya.values[ok],
                                        cv=KFold(5, shuffle=True, random_state=RANDOM_STATE),
                                        scoring="r2").mean()
                print(f"[caveat] Same features predict AGE with CV R2={r2age:.3f}. "
                      "Because cohorts differ in age, part of the group signal may be age, "
                      "not experience — control for age before claiming an experience effect.")

    # --- regression of ordinal experience ---
    EXP = EXPERIENCE_COL or next((c for c in ["Meditation_level", "Meditation_length"]
                                  if c in participants.columns), None)
    if EXP:
        y = participants.set_index(SUBJ_COL)[EXP]
        d = Xf.join(y.rename("y")).dropna()
        Xr, yr = d.drop(columns="y").values, d["y"].values
        for name, mdl in {"Ridge": make_pipeline(StandardScaler(), RidgeCV(alphas=np.logspace(-2, 3, 20))),
                          "RF": RandomForestRegressor(400, random_state=RANDOM_STATE)}.items():
            cv = KFold(5, shuffle=True, random_state=RANDOM_STATE)
            r2 = cross_val_score(mdl, Xr, yr, cv=cv, scoring="r2")
            _, _, p = permutation_test_score(mdl, Xr, yr, cv=cv, scoring="r2",
                                             n_permutations=100, random_state=RANDOM_STATE)
            print(f"{EXP} ~ {name}: CV R2={r2.mean():.3f}+/-{r2.std():.3f} | perm p={p:.3f}")


# ## SECTION 5 — Reporting checklist
# 
# - Confirm what `Group` is (Section 0 cross-tabs). If it is an ordination/experience tier, frame the
#   paper as **temporal dynamics x meditation experience**.
# - Primary result: Section 2 — overall trajectory shape (FDR) AND the time x group interaction
#   (does experience change the trajectory?). Lead with **relative** power; use absolute only to show
#   whether the effect is global vs band-specific (Section 1b).
# - Phenotypes (Section 3) and group decoding (Section 4) are secondary/confirmatory.
# - If, after log-transform + relative power + clean channels, the temporal effects are still null,
#   that is a legitimate finding (stability of the expert meditative EEG state); report it as such
#   with the trajectory CIs, rather than searching for a significant subset.
# print("\nDone. Outputs in", OUTPUT_DIR)

# In[ ]:




