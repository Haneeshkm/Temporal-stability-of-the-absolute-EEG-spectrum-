#!/usr/bin/env python
# coding: utf-8

# ## Standalone validation of the relative-power temporal dynamics
# 
# Run this on its own — it does **not** need any other cell to have run first, and it never opens a raw `.xls`/`.xlsx` file. It just reads the two CSVs the v3 pipeline already saved (`tables/roi_power.csv` and `tables/tidy_long.csv`).
# 
# **Before running:** set `OUTPUT_DIR` below to the same value as in your v3 notebook (default `./meditation_eeg_outputs_v2`), and run from the same working directory where v3 wrote its outputs. If it can't find the files, run `print(OUTPUT_DIR.resolve())` to see where it's looking.

# In[1]:


# --- config: match this to OUTPUT_DIR in your v3 notebook ---
from pathlib import Path
import numpy as np, pandas as pd
import statsmodels.formula.api as smf
import warnings; warnings.filterwarnings("ignore")

OUTPUT_DIR = Path(__import__("os").environ.get("EEG_OUTPUT_DIR", "./outputs"))   # <-- must match your v3 CONFIG
BAND_ORDER = ["Delta", "Theta", "Alpha", "Beta", "Gamma"]
INTERVAL_ORDER = ["0-5min", "5-10min", "10-15min", "15-20min", "20-25min", "25-30min"]
TIME_MID = {iv: 2.5 + 5 * i for i, iv in enumerate(INTERVAL_ORDER)}

roi_tbl = pd.read_csv(OUTPUT_DIR / "tables" / "roi_power.csv")
tidy = pd.read_csv(OUTPUT_DIR / "tables" / "tidy_long.csv")
if "time_min" not in tidy.columns:
    tidy["time_min"] = tidy["time_interval"].map(TIME_MID)
if "y" not in roi_tbl.columns:
    roi_tbl["y"] = np.log10(roi_tbl["power"].clip(lower=1e-9))
print("Loaded:", roi_tbl.shape, tidy.shape, "| power types:", sorted(tidy["power_type"].unique()))


# In[2]:


# --- 1) Group-mean relative power per interval, and quadratic-coefficient sign ---
REL = roi_tbl[roi_tbl["power_type"] == "relative"].copy()
tvals = sorted(REL["time_min"].unique())

print("Group-mean RELATIVE power (%) per 5-min interval (whole-scalp), per band:")
gm = REL.groupby(["band", "time_min"])["power"].mean().unstack("time_min").reindex(BAND_ORDER)
print(gm.round(2).to_string())

REL["t"] = (REL["time_min"] - REL["time_min"].mean()) / REL["time_min"].std()
REL["t2"] = REL["t"] ** 2
rows = []
for (b, r), d in REL.groupby(["band", "roi"]):
    try:
        m = smf.mixedlm("y ~ t + t2", d, groups=d["subject_id"], re_formula="~t").fit(reml=False)
        rows.append(dict(band=b, roi=r, quad_coef=m.fe_params["t2"]))
    except Exception:
        pass
qc = pd.DataFrame(rows).pivot(index="band", columns="roi", values="quad_coef").reindex(BAND_ORDER)
print("\nQuadratic coefficient sign (+ U-shaped / - inverted-U), relative power:")
print(qc.round(4).to_string())


# In[3]:


# --- 2) Robustness: leave-one-interval-out on the strongest effect ---
print("Leave-one-interval-out (Theta, Parietal): quadratic p with each interval removed")
d0 = REL[(REL.band == "Theta") & (REL.roi == "Parietal")]
for drop in tvals:
    dd = d0[d0.time_min != drop]
    m = smf.mixedlm("y ~ t + t2", dd, groups=dd["subject_id"], re_formula="~t").fit(reml=False)
    print(f"  drop {drop:>4.1f} min -> quad p = {m.pvalues['t2']:.4f}")


# In[4]:


# --- 3) Compositional (CLR) re-test: the line that decides the paper ---
print("Compositional (CLR) re-test of curvature (proper for sum-to-100 data):")
W = (tidy[tidy.power_type == "relative"]
     .groupby(["subject_id", "time_min", "band"])["power"].mean()
     .unstack("band")[BAND_ORDER]).clip(lower=1e-6)
clr = np.log(W).sub(np.log(W).mean(axis=1), axis=0).reset_index()
for b in ["Alpha", "Theta"]:
    dd = clr[["subject_id", "time_min", b]].rename(columns={b: "y"})
    dd["t"] = (dd.time_min - dd.time_min.mean()) / dd.time_min.std(); dd["t2"] = dd.t ** 2
    m = smf.mixedlm("y ~ t + t2", dd, groups=dd["subject_id"], re_formula="~t").fit(reml=False)
    print(f"  {b}: CLR quad coef={m.fe_params['t2']:+.4f} (p={m.pvalues['t2']:.4g}) | "
          f"lin coef={m.fe_params['t']:+.4f} (p={m.pvalues['t']:.4g})")


# In[ ]:




